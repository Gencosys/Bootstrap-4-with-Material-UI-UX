---
layout: docs
title: Extensions
group: material-design
---

Material Design for Bootstrap provides seamlessly integration with some extensions.

- [SnackbarJS]({{ site.baseurl }}/docs/4.0/material-design/snackbars)
